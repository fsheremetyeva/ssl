<?
/*
class components extends AppController{


  public function __construct(){

  }
    public function index(){
    $menu = array(
      "Controller" => "?controller=components",
      "Modal" => "?view=modal",
      "Carousel" => "?view=carousel",
      "Progess" => "?view=progress",
      "Popover" => "?view=popover"

    );

    $this->getView("header", array("pagename"=>"welcome"));
    $this->getView("navigation", $menu);
    switch((isset($_GET['view']) ? $_GET['view'] : null))
    {
      case 'carousel':
          $view = 'carousel';
          break;
            case 'modal':
                $view = 'modal';
                break;
          case 'popover':
                    $view = 'popover';
                    break;
          case 'progress':
                    $view = 'progress';
                    break;
          default:
          $view = 'welcome';
          break;
    }
    $this->getView($view);
    $this->getView("footer");
  }


}
*/
?>
