

  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container">

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">

          <?
            foreach($data as $key => $item){
              if(strpos($_SERVER['REQUEST_URI'], $item) !== false)
                echo " <li class='active nav-item'>";
              else
                echo " <li class='nav-item'>";

              echo "    <a class='nav-link' href='".$item."'>";
              echo "$key
                  </a>
                </li> ";
            }
            ?>
        <!--   <li class="nav-item active">
            <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Link</a>
          </li>
          <li class="nav-item">
            <a class="nav-link disabled" href="#">Disabled</a>
          </li>
         <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="http://example.com" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <a class="dropdown-item" href="#">Something else here</a>
            </div>
          </li> -->
        </ul>
        <span style="color:red"><?=@$_REQUEST["msg"]? $_REQUEST["msg"] :''; ?></span>
        <?
          if(@$_SESSION["loggedin"] && @$_SESSION["loggedin"]==1){?>
            <form class="navbar-form navbar-right">
              <a href="/profile">Profile</a> |
              <a  href="/auth/logout">Logout</a>
            </form>
          <?}else{?>
            <form id="navbar-login" class="form-inline my-2 my-lg-0" method="post" action="/auth/login">
              <div class="form-group">
                <label class="white" for="username">Username</label>
                <input type="text" class="form-control" name="username" id="username" aria-describedby="usernameHelp" placeholder="Username">
              </div>
              <div class="form-group">
                <label class="white" for="password">Password</label>
                <input type="password" class="form-control" name="password" id="password" placeholder="Password">
              </div>
              <button type="submit" class="btn btn-primary">Login</button>
            </form>
            <?}

            ?>



      </div>
    </div>
  </nav>

<!--
<nav>
  <ul class="nav-menu">


  <?
    /*
    foreach($data as $key => $item){
      echo " <li class='nav-item'>
          <a href='".$item."'>
            ".$key."
          </a>
        </li> ";
    }
*/
    ?>


  </ul>
</nav> -->
