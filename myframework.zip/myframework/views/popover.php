

  <button type="button" class="btn btn-secondary" data-container="body" data-toggle="popover" data-placement="right" data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus.">
    Popover on right
  </button>


<script>
$(function () {
    $('[data-toggle="popover"]').popover()
})

</script>
