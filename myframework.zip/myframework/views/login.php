
<div class="container">
  <h1>Please login below</h1>
<form action="/welcome/contactRecv" method="POST">
  <div class="form-group">
    <label for="email">Email address</label>
    <input name="email" type="email" class="form-control" id="email" placeholder="name@example.com">
  </div>
  <div class="form-group">
    <label for="password">Password</label>
    <input name="password" type="password" class="form-control" id="password" placeholder="password">
  </div>

  <input type="buton" class="btn" value="Ajax Submit" id="ajaxbutton">
</form>
<div id="feedback"></div>
</div>
