<?


/*
1) Complete Development Environment Setup and create a Hello World application:

Create a class
Instantiate a class - in activity1-1.php
Use a method from the class - Using in activity1-1.php

*/
class helloclass{
  public function __construct(){

    echo "Hello World <br>";


  }

  public function printFunction($name, $age){

    echo "My name is ".$name. " and age is ". $age . "<br>";

  }
}




?>
